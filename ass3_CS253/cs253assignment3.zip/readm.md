Run the file-
Run it in jupyter notebook and for changing the data file name just change it in the 4th line of 1st block
Note-
1. We have given the name of top 10 words in both spam and non-spam.