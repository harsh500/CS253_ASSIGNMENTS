Command-
g++ lbs.cpp
./a.out
