Commands:
chmod +x lab.sh
./lab.sh <inputfile> <outputfile>
Note: If output file not exist then it well make one
